# Aqua Cloud Scraper Phase 1

Version 2.0.0. Python 3.10+. Collect public product information, retain source evidence, resume unfinished work, and generate a Word handbook. No account or AI API key is needed. This release implements Phase 1 only: reliable collection. AI narrative writing, screenshots, PDF parsing, video transcription and scheduled change reports remain outside this release.

## What changed

- Discovers pages from the documentation `llms.txt` index, robots-advertised XML sitemaps and page links. Nested sitemap cycles and discovery volume are bounded. Known editorial post/category/author sitemaps and recognised non-English paths are excluded; this remains a heuristic scope, not an exhaustive language classifier.
- Prioritises documentation and page sitemaps, gives starting URLs priority, and balances subsequent page selection using topic coverage. HTML and Markdown variants of the same GitBook URL share one queue identity.
- Checks headings, explanatory text, article structure, navigation-only pages and known access-wall signals. A long blocked page is not automatically a successful result.
- Captures visible rendered content after a configurable stable-text interval; supports bounded scrolling, native disclosure sections and ARIA tabs linked to tab panels. Inspected selectors can be supplied for consent, accordions and tour Next controls.
- Splits each page into sections with heading paths, source IDs, source URLs, collection timestamps and browser-state references. Topic assignment uses each section's heading and text, falling back to URL keywords.
- Suppresses exact repeated passages in the Word reading copy but retains both records and all text in JSON. Near-duplicates are flagged and kept, so changed values and qualifications are not lost. This uses text shingles, not an AI semantic model.
- Persists the pending queue, completed records, in-flight URL and settings in an atomic checkpoint. Resume skips completed URLs. An interrupted in-flight URL is tried again.
- Creates a unique dated folder for every fresh run and a new timestamped Word report after every completed collection session. Earlier Word files are retained.

## First-time setup

Extract this package and open a terminal in `aqua_cloud_scraper`.

Windows:

```powershell
py -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt
.venv\Scripts\python -m playwright install chromium
.venv\Scripts\python aqua_scraper.py --max-pages 10
```

macOS/Linux:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m playwright install chromium
.venv/bin/python aqua_scraper.py --max-pages 10
```

After installation, `run_windows.bat` or `bash run_mac_linux.sh` starts a normal run. The launchers do not install dependencies. Playwright is pinned to the version used by the browser tests. On minimal Linux machines, follow Playwright's missing-library instructions if Chromium cannot launch.

All `python` examples below mean the virtual-environment interpreter shown above. Use that explicit path unless the environment is activated.

## Fresh runs

```bash
# Default: up to 50 page attempts and 8 index attempts, maximum link depth 3
python aqua_scraper.py

# Quick HTTP-only collection: no Chromium required
python aqua_scraper.py --mode http --max-pages 10

# More extensive collection
python aqua_scraper.py --max-pages 100 --max-depth 4 --output output_detailed

# Product tour only: no index bootstrap or linked pages
python aqua_scraper.py --seed https://aqua-cloud.io/product-tour/ --max-pages 1 --max-depth 0 --no-discovery

# Documentation-focused seeds without site-wide index bootstrap
python aqua_scraper.py --seed https://docs.aqua-cloud.io/documentation --no-discovery --max-pages 50
```

The default seeds are the product tour, documentation root, product FAQ and pricing. Automatic discovery also bootstraps the official documentation index. Use `--no-discovery` to disable that bootstrap and robots-advertised sitemaps; relevant links on collected pages are still followed up to the depth limit. For an isolated seed use both `--no-discovery` and `--max-depth 0`.

Page attempts include failures. Index requests have a separate budget. Robots requests and retries are not counted as page attempts. Sitemap entries begin at their discovery depth; the depth limit applies to subsequent page-link traversal rather than URL directory depth. The depth limit is therefore not a complete request budget: use the page, index and frontier limits as well.

## Output structure

A fresh run prints its exact folder, for example `output/run_20261031T120000Z_a1b2c3d4`. Run timestamps use UTC. Never copy this example literally for resume; use the folder printed by your run.

| File | Purpose |
| --- | --- |
| `checkpoint.json` | Durable queue, settings, completed status records, in-flight task and collected sections; required to resume |
| `aqua_data.json` | Exported source collection, sections, source links, issues and pending URLs |
| `coverage.json` | Run status, page-status counts, topic section counts, duplicate counts and remaining work |
| `scrape.log` | Collection progress and errors; appended when resuming the same run |
| `latest_report.json` | Relative path of the most recently generated Word report |
| `reports/Aqua_Cloud_Handbook_TIMESTAMP.docx` | A new Word report for each collection session that has usable sources |
| `run.lock` | OS-backed lock preventing simultaneous writers; it can remain on disk after a run |

The Word report still has 14 topic chapters and now files individual feature sections into them. Each section has a source reference. Exact duplicates point to an earlier section. Similar sections remain visible with a note. Empty topics, pending URLs and collection limits are clearly distinguished from evidence that a product feature is absent.

The JSON and checkpoint are updated within a run. Word reports are versioned. Old run folders are preserved. Do not edit a checkpoint while a run is active, and keep checkpoints private if you later extend the tool to sensitive sources.

## Resume and retry

```bash
python aqua_scraper.py --resume "output/YOUR_RUN_FOLDER" --max-pages 50
```

This uses the saved configuration and attempts up to 50 **additional** pages. Previously collected, failed and skipped URLs are not automatically fetched again. Pending indexes receive another per-session index budget. Completed report versions remain in the reports folder.

To retry pages that failed, were blocked, or had too little content:

```bash
python aqua_scraper.py --resume "output/YOUR_RUN_FOLDER" --retry-failed --max-pages 20
```

Failed indexes are retained as issues and are not automatically requeued by `--retry-failed`; start a new run to repeat discovery. A permanent access restriction may fail again. An empty queue plus failed records means the attempted collection finished with gaps, not that the website was fully captured.

Resume uses stored settings. The new page budget, retry flag and an explicitly supplied browser executable path are applied; other configuration flags are not changes to the saved crawl. Start a fresh run to change mode, depth, seeds, discovery or interaction settings. If a user interrupts or the process crashes, the OS releases its lock automatically. The next resume retries the saved in-flight task. A partially completed HTTP request may therefore occur again; a completed source record is not duplicated.

Version 1 JSON cannot resume because it has no durable queue. It can still rebuild a Word report using `--from-json`.

## Offline document rebuilding

```bash
python aqua_scraper.py --from-json "output/YOUR_RUN_FOLDER/aqua_data.json" --output rebuilt
```

This makes no network requests and writes a new Word document into a new dated folder. Both v1 and v2 source JSON are supported. Add `--max-words-per-section 1200` for a bounded reading copy. Zero, the default, includes every collected word. With legacy v1 input the cap applies per source page, matching the old data structure. Truncation is labelled.

## Browser collection

```bash
python aqua_scraper.py --mode browser --max-pages 5
python aqua_scraper.py --mode browser --headed --seed https://aqua-cloud.io/product-tour/ --max-pages 1 --no-discovery --max-depth 0
```

In auto mode, a thin or navigation-only direct response can trigger browser rendering. Explicit access/login/consent-wall signals are recorded without trying to bypass them. HTTP errors such as 401/403 are not converted into a browser bypass attempt.

The browser waits for meaningful visible content and an unchanged text signature over `--settle-ms` (default 1200). `--ready-selector` can require a specific inspected element. Rendering and interaction waits are bounded by `--timeout`. Default scrolling is capped at 8 iterations, and total disclosure/tab/accordion/Next actions are capped at 20. These controls reduce uncertainty; they do not prove every future asynchronous update has completed.

Native `details` disclosures and ARIA tabs with a matching tab panel are read automatically. Use `--no-interact` to disable those automatic actions. Consent choices are not made automatically. Custom accordion and Next selectors must be inspected and deliberately supplied. Do not use placeholders literally:

```bash
python aqua_scraper.py --mode browser --seed https://aqua-cloud.io/product-tour/ --max-pages 1 --no-discovery --max-depth 0 --consent-selector "YOUR_CHOICE_SELECTOR" --accordion-selector "YOUR_CONTENT_BUTTON_SELECTOR" --next-selector "YOUR_NEXT_SELECTOR" --max-interactions 20
```

Selectors apply to each rendered page, so first test them with a single seed. Partial interaction results are retained with a note if a later action fails. The code records state hashes and source URLs; it does not save login sessions or upload screenshots. External iframe navigation is blocked by scope, and iframe internals are not extracted.

If the Playwright browser download is unavailable, you can supply an installed Chromium-compatible executable:

```bash
python aqua_scraper.py --mode browser --browser-executable "/absolute/path/to/browser"
```

If your environment requires an HTTP proxy, `--proxy-env` passes `HTTPS_PROXY` or `HTTP_PROXY` to the browser. Proxy credentials are read from the environment rather than stored in the checkpoint. HTTP requests already use the standard Python proxy environment. Browser TLS verification remains enabled. Configure a trusted environment rather than disabling certificate checks to make a test appear successful.

## Limits and interpretation

- Scope is restricted to public Aqua marketing and documentation hosts. This is not a login automation tool, private application crawler or general internet spider.
- Discovery supports uncompressed XML sitemaps and the documentation Markdown index. Compressed or malformed index responses are recorded as errors.
- Page classification uses deterministic keyword scoring, not AI reasoning. Review ambiguous sections before treating the document as authoritative.
- Exact text duplicates are linked; near-duplicate detection uses a four-word shingle overlap threshold of 0.82 and never deletes differing passages. Distinct sections can still contain repeated marketing text.
- HTML parsing can include inactive source content; browser mode captures visible states. Neither method proves that a feature is released or included in a subscription. Availability labels are preserved where extracted.
- The standard Python robots parser is used. Its syntax support does not match every search-engine implementation. A 404 means no published robots file; unavailable or invalid robots content causes a host to be skipped.
- Defaults: one-second host pacing, 30-second request timeout, two retries, 8 MB response cap, 5,000 discovered task identities. Larger server retry delays are recorded for later retry rather than ignored.
- Exit code 0 means at least one usable source produced a handbook. Exit code 2 means no usable source or a setup failure. Inspect coverage regardless of exit code.

## Code map

| File | Responsibility |
| --- | --- |
| `aqua_scraper.py` | Command-line entry point |
| `collection.py` | Scope, fetches, discovery, quality checks, sections, duplicates, checkpointing and resume |
| `browser_capture.py` | Browser readiness, visible snapshots and bounded interaction |
| `content_core.py` | HTML/Markdown helpers, topic definitions, Word styles and v1 report compatibility |
| `report.py` | Section-based v2 Word generation |
| `tests/fixture_server.py` | Local HTML, Markdown, sitemap, failure and dynamic UI fixtures |
| `tests/test_phase1.py` | Phase 1 integration, resilience and browser tests |
| `tests/test_scraper.py` | Retained extraction regression tests |

## Verification

```bash
python -m unittest discover -s tests -v
```

Real browser tests are opt-in so an HTTP-only installation can run the remaining tests. On macOS/Linux:

```bash
AQUA_BROWSER_TESTS=1 python -m unittest discover -s tests -v
```

On Windows PowerShell:

```powershell
$env:AQUA_BROWSER_TESTS="1"
python -m unittest discover -s tests -v
```

Set `AQUA_BROWSER_EXECUTABLE` to use a specific installed browser for tests. Browser fixtures run on a temporary local server and do not contact the real Aqua website. See `VALIDATION.md` for exact test outcomes and the separate live-site limitations.
