# Phase 1 validation

Validated on 31 October 2026 with Python 3.12 on Linux.

## Automated checks

45 tests passed, with no skips in the final run. This includes four real browser tests using Google Chrome Headless Shell 145.0.7632.6 and Playwright 1.58.0.

The browser checks use a local HTTP fixture server and verify delayed JavaScript rendering, HTTP-to-browser fallback, native disclosure controls, ARIA tabs, an explicitly configured consent choice, a configured accordion, a Next control, hidden-content exclusion and the interaction limit. Other tests cover scoped URLs, nested sitemap cycles, editorial-index exclusion, documentation URL aliases, section classification, access walls, exact and near duplicates, redirects, robots denial, retries, rate limits, atomic checkpoints, interruption/crash recovery, saved-queue resume, failed-page retry, output versioning, file locking, Word creation, labelled truncation and offline rebuilding.

## Live HTTP collection and resume

A six-page collection followed by a two-page resume produced eight collected source records and two timestamped Word reports. The resumed session retained the first six records. The collected records contain 131 sections. Live HTTP checks exercised HTML, Markdown, documentation-index discovery and nested XML sitemap discovery.

The live runs informed two final discovery fixes: filtering recognised German documentation paths and giving HTML/Markdown documentation aliases one queue identity. These final changes passed regression tests; the entire live crawl was not repeated after those filtering changes. The live checks are bounded samples, not a completeness claim.

Sources collected:

- https://aqua-cloud.io/pricing/ — http HTML; 19 sections
- https://aqua-cloud.io/product-tour/ — http HTML; 22 sections
- https://aqua-cloud.io/aqua-cloud-faq/ — http HTML; 80 sections
- https://docs.aqua-cloud.io/documentation — http Markdown; 2 sections
- https://docs.aqua-cloud.io/documentation/agile — http Markdown; 2 sections
- https://docs.aqua-cloud.io/documentation/reporting — http Markdown; 2 sections
- https://docs.aqua-cloud.io/documentation/administration — http Markdown; 2 sections
- https://docs.aqua-cloud.io/documentation/integrations/sso — http Markdown; 2 sections

## Live browser limitation

The standard Playwright download endpoint returned invalid archives in this environment. An official Chrome Headless Shell archive downloaded from Google's storage endpoint launched successfully and passed all four local browser tests. The browser binary is not bundled.

A live navigation to the Aqua product tour failed with ERR_EMPTY_RESPONSE without the environment proxy and ERR_CERT_AUTHORITY_INVALID when the proxy was configured. Certificate verification was not disabled. Therefore the browser engine is verified on controlled fixtures, but live browser extraction of Aqua's tour is not verified here. Direct HTTP extraction of the live tour succeeded.

## Document and platform checks

The updated four-page Word user guide was rendered and every page visually inspected. The generated handbook's source text, section IDs and truncation notices are covered by automated checks. Windows and macOS launchers were not executed on those operating systems. The tests do not establish complete coverage of every custom widget or future site layout.

## Installed dependency versions

- lxml: 6.1.1
- python-docx: 1.2.0
- playwright: 1.58.0
- markdown-it-py: 4.2.0
