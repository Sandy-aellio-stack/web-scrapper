"""Phase 1 collection engine: scoped discovery, durable state and section evidence."""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import logging
import os
import re
import time
import uuid
from collections import Counter
from contextlib import contextmanager
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from pathlib import Path
from types import SimpleNamespace
from urllib.parse import urljoin, urlsplit, urlunsplit, unquote
from urllib.request import Request, build_opener, HTTPRedirectHandler
from urllib.error import HTTPError, URLError
from urllib.robotparser import RobotFileParser

from lxml import etree
import content_core as core

SCHEMA = 2
UA = 'AquaDocumentationCollector/2.0'
LOG = logging.getLogger('aqua')


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(text):
    return hashlib.sha256(text.encode('utf-8')).hexdigest()


def url_identity(url):
    # GitBook serves the same documentation as HTML and Markdown. Keep the
    # originally requested URL as evidence, but schedule only one representation.
    return url[:-3] if urlsplit(url).hostname == 'docs.aqua-cloud.io' and url.endswith('.md') else url


def atomic_json(path, value):
    path = Path(path)
    tmp = path.with_name(path.name + '.tmp')
    with tmp.open('w', encoding='utf-8') as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.flush(); os.fsync(f.fileno())
    os.replace(tmp, path)


@contextmanager
def run_lock(directory):
    """OS lock is released even if the process dies; no stale PID recovery needed."""
    file = (Path(directory) / 'run.lock').open('a+b')
    file.seek(0); file.write(b'0'); file.flush(); file.seek(0)
    locked = False
    try:
        if os.name == 'nt':
            import msvcrt
            msvcrt.locking(file.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(file, fcntl.LOCK_EX | fcntl.LOCK_NB)
        locked = True
        yield
    except (BlockingIOError, PermissionError) as e:
        raise RuntimeError('This run directory is already in use') from e
    finally:
        if locked:
            file.seek(0)
            if os.name == 'nt':
                import msvcrt
                msvcrt.locking(file.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(file, fcntl.LOCK_UN)
        file.close()


class Scope:
    def __init__(self, fixture_origin=None):
        # Test-only dependency injection, never exposed through the CLI.
        self.fixture_origin = fixture_origin

    def url(self, value, base=None, index=False):
        try:
            p = urlsplit(urljoin(base or core.SEEDS[0], value))
            if p.username or p.password:
                return None
            origin = f'{p.scheme}://{p.netloc}'
            local = bool(self.fixture_origin and origin == self.fixture_origin)
            if not local and (p.scheme != 'https' or p.hostname not in core.HOSTS or p.port not in (None, 443)):
                return None
            path = re.sub('/+', '/', p.path or '/')
            decoded = unquote(path)
            if '..' in decoded.split('/') or re.search(r'/(?:de|es|fr|v/de|v/es|de-documentation|es-documentation|fr-documentation)(?:/|$)', decoded, re.I):
                return None
            if not index:
                if core.SKIP_PATH.search(path) or core.FILE_SUFFIX.search(path):
                    return None
                if p.hostname == 'docs.aqua-cloud.io' and not path.startswith('/documentation'):
                    return None
                if p.hostname == 'www.aqua-cloud.io':
                    origin = 'https://aqua-cloud.io'
                if path != '/' and not re.search(r'\.[a-z0-9]+$', path, re.I):
                    path = path.rstrip('/') if p.hostname == 'docs.aqua-cloud.io' else path.rstrip('/') + '/'
            return origin + path
        except (ValueError, TypeError):
            return None

    def relevant(self, url):
        if self.fixture_origin:
            return True
        return core.relevant(url)


class FetchError(Exception):
    def __init__(self, message, category='request_error'):
        super().__init__(message); self.category = category


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None


class Fetcher:
    def __init__(self, scope, config):
        self.scope, self.config = scope, config
        self.opener = build_opener(NoRedirect())
        self.robots, self.robot_status, self.sitemaps, self.last = {}, {}, {}, {}

    def pace(self, url):
        origin = urlsplit(url).netloc
        p = self.robots.get(origin)
        delay = max(self.config.delay, (p.crawl_delay(UA) or 0) if p else 0)
        time.sleep(max(0, delay - (time.monotonic() - self.last.get(origin, 0))))
        self.last[origin] = time.monotonic()

    def request(self, url, index=False, robots_request=False):
        current = self.scope.url(url, index=index or robots_request)
        if not current:
            raise FetchError('URL outside public collection scope', 'scope')
        for _ in range(6):
            if not robots_request and not self.allowed(current):
                raise FetchError('Robots disallow or robots unavailable', 'robots')
            for attempt in range(self.config.retries + 1):
                self.pace(current)
                try:
                    req = Request(current, headers={'User-Agent': UA, 'Accept': 'text/html,text/markdown,text/plain,application/xml;q=0.9'})
                    with self.opener.open(req, timeout=self.config.timeout) as response:
                        data = response.read(8_000_001)
                        if len(data) > 8_000_000:
                            raise FetchError('Response exceeds 8 MB', 'size_limit')
                        return {'raw': data.decode(response.headers.get_content_charset() or 'utf-8', errors='replace'),
                                'url': current, 'content_type': response.headers.get('Content-Type', '').lower(), 'status': response.status}
                except HTTPError as e:
                    if e.code in {301, 302, 303, 307, 308}:
                        target = self.scope.url(e.headers.get('Location', ''), current, index=index or robots_request)
                        if not target:
                            raise FetchError('Redirect outside public collection scope', 'scope') from e
                        # robots.txt cannot silently delegate its policy to a different host.
                        if robots_request and urlsplit(target).netloc != urlsplit(current).netloc:
                            raise FetchError('Cross-host robots redirect rejected', 'robots') from e
                        current = target
                        break
                    if (e.code == 429 or e.code >= 500) and attempt < self.config.retries:
                        retry = e.headers.get('Retry-After', '')
                        try:
                            delay = float(retry) if retry.isdigit() else (parsedate_to_datetime(retry) - datetime.now(timezone.utc)).total_seconds()
                        except (ValueError, TypeError, OverflowError):
                            delay = 2 ** (attempt + 1)
                        if delay > 60:
                            raise FetchError('Server requested a retry after more than 60 seconds; retry this URL later', 'rate_limit') from e
                        time.sleep(max(1, delay)); continue
                    raise FetchError(f'HTTP {e.code}', 'access' if e.code in (401, 403) else 'http') from e
                except (URLError, TimeoutError, OSError) as e:
                    if attempt < self.config.retries:
                        time.sleep(2 ** (attempt + 1)); continue
                    raise FetchError(str(e), 'network') from e
            else:
                raise FetchError('Retries exhausted')
        raise FetchError('Redirect limit exceeded', 'redirect')

    def allowed(self, url):
        p = urlsplit(url); key = p.netloc
        if key not in self.robots:
            self.robots[key] = None
            try:
                data = self.request(f'{p.scheme}://{p.netloc}/robots.txt', robots_request=True)
                if '<html' in data['raw'][:500].lower():
                    raise FetchError('robots.txt returned HTML')
                parser = RobotFileParser(); parser.parse(data['raw'].splitlines())
                self.robots[key] = parser
                self.robot_status[key] = 'loaded'
                self.sitemaps[key] = [u for line in data['raw'].splitlines()
                                     if line.lower().startswith('sitemap:')
                                     if (u := self.scope.url(line.split(':', 1)[1].strip(), url, index=True))]
            except FetchError as e:
                if str(e) == 'HTTP 404':
                    parser = RobotFileParser(); parser.parse(['User-agent: *', 'Allow: /'])
                    self.robots[key] = parser; self.robot_status[key] = 'not published HTTP 404'
                else:
                    self.robot_status[key] = 'unavailable: ' + str(e)
        parser = self.robots[key]
        return parser is not None and parser.can_fetch(UA, url)


def parse_page(response, scope):
    raw, url, ctype = response['raw'], response['url'], response['content_type']
    if 'html' in ctype:
        parsed = core.extract_html(raw, url); method = 'http HTML'
    elif any(t in ctype for t in ('text/plain', 'text/markdown')):
        body = re.split(r'(?m)^# Agent Instructions\s*$', raw, maxsplit=1)[0]
        rendered = core.MarkdownIt('commonmark').enable('table').render(body)
        parsed = core.extract_html('<main>' + rendered + '</main>', url)
        headings = [b['text'] for b in parsed['blocks'] if b['kind'] == 'heading']
        parsed['title'] = headings[0] if headings else url
        method = 'http Markdown'
    else:
        raise FetchError('Unsupported content type ' + ctype, 'content_type')
    # Collect links separately, including test fixtures; all paths still pass Scope.
    if 'html' in ctype:
        doc = core.html.fromstring(raw)
    else:
        doc = core.html.fromstring('<main>' + rendered + '</main>')
    parsed['links'] = sorted({u for href in doc.xpath('//a[@href]/@href') if (u := scope.url(href, url))})
    parsed['method'] = method
    parsed['quality'] = quality(parsed, raw)
    return parsed


def quality(page, raw=''):
    blocks = page['blocks']
    headings = [b['text'] for b in blocks if b['kind'] == 'heading']
    prose = [b['text'] for b in blocks if b['kind'] != 'heading']
    words = sum(len(t.split()) for t in prose)
    lead = ' '.join([page['title'], *headings[:2]]).lower()
    patterns = [r'\baccess denied\b', r'\bverify (?:you are|you.re) human\b', r'\bjust a moment\b', r'\bchecking your browser\b']
    reasons = []
    if any(re.search(p, lead) for p in patterns):
        return {'status': 'blocked', 'reasons': ['access or login heading'], 'body_words': words}
    if re.search(r'^\s*(?:sign in|log in|login)\b', lead) and words < 80:
        return {'status':'blocked','reasons':['login screen with little article content'],'body_words':words}
    if re.search(r'type\s*=\s*["\x27]password', raw, re.I) and words < 100:
        return {'status': 'blocked', 'reasons': ['password form with little article content'], 'body_words': words}
    if any(re.search(r'\b(?:cookie consent|privacy preference|consent required|accept cookies to continue)\b', h, re.I) for h in headings[:2]) and words < 180:
        return {'status': 'blocked', 'reasons': ['consent page dominates content'], 'body_words': words}
    meaningful = [p for p in prose if len(p.split()) >= 8]
    if words >= 35 and meaningful or (words >= 12 and meaningful and headings):
        status = 'usable'
    elif len(page.get('links', [])) >= 2:
        status = 'navigation'; reasons.append('links available but insufficient explanatory prose')
    else:
        status = 'thin'; reasons.append('no meaningful article structure or sufficient prose')
    return {'status': status, 'reasons': reasons, 'body_words': words, 'headings': len(headings), 'prose_blocks': len(meaningful)}


def split_sections(page):
    sections, current, labels = [], None, []
    context = []
    for block in page['blocks']:
        text = block['text']
        if block['kind'] == 'heading':
            if current and current['blocks']:
                sections.append(current)
            level = block.get('level', 2)
            context = [x for x in context if x[0] < level] + [(level, text)]
            current = {'heading': text, 'heading_path': [x[1] for x in context], 'blocks': labels, 'level': level}
            labels = []
        elif len(text) < 40 and re.search(r'\b(coming soon|beta|preview|deprecated)\b', text, re.I):
            labels.append(block)
        else:
            if current is None:
                current = {'heading': page['title'], 'heading_path': [page['title']], 'blocks': [], 'level': 1}
            current['blocks'].extend(labels); labels = []
            current['blocks'].append(block)
    if current:
        current['blocks'].extend(labels)
        if current['blocks']:
            sections.append(current)
    for i, section in enumerate(sections):
        section['id'] = page['id'] + f'-C{i + 1:03d}'
        section['topic'], section['classification'] = classify(section, page['url'])
        section['text_hash'] = digest(' '.join(b['text'] for b in section['blocks']))
    return sections


def classify(section, url):
    def norm(t):
        return re.sub(r'[^a-z0-9]+', ' ', t.lower()).strip()
    heading = norm(section['heading'])
    body = norm(' '.join(b['text'] for b in section['blocks']))
    scores = []
    extras = {2: ['test case', 'test data'], 4: ['bug', 'defect'], 6: ['ai', 'artificial intelligence'],
              7: ['api', 'integration'], 10: ['security', 'access control', 'permissions'], 12: ['price', 'billing']}
    for i, (_, keywords, _) in enumerate(core.TOPICS):
        terms = [norm(k) for k in keywords] + extras.get(i, [])
        score = sum(4 * bool(re.search(r'\b' + re.escape(k) + r'\b', heading)) + bool(re.search(r'\b' + re.escape(k) + r'\b', body)) for k in set(terms) if k)
        scores.append(score)
    best = max(scores)
    index = scores.index(best) if best else core.topic_for(url)
    return index, {'method': 'heading and text keywords' if best else 'URL fallback', 'score': best}


def deduplicate(pages):
    """Only exact duplicates are suppressed. Similar passages retain all evidence."""
    exact, seen = {}, []
    for page in pages:
        for section in page['sections']:
            for key in ('duplicate_of', 'near_duplicate_of', 'similarity'):
                section.pop(key, None)
            text = core.clean(' '.join(b['text'] for b in section['blocks'])).casefold()
            key = digest(text)
            if len(text.split()) >= 10 and key in exact:
                section['duplicate_of'] = exact[key]
            elif len(text.split()) >= 10:
                exact[key] = section['id']
            tokens = re.findall(r'\w+', text)
            shingles = {tuple(tokens[i:i+4]) for i in range(len(tokens)-3)}
            if len(tokens) >= 30 and 'duplicate_of' not in section:
                for prior_id, prior in seen:
                    ratio = len(shingles & prior) / max(1, len(shingles | prior))
                    if ratio >= .82:
                        section['near_duplicate_of'], section['similarity'] = prior_id, round(ratio, 3)
                        break
                seen.append((section['id'], shingles))


def index_links(raw, url, scope):
    if raw.lstrip().startswith('<'):
        parser = etree.XMLParser(resolve_entities=False, no_network=True, recover=False)
        root = etree.fromstring(raw.encode(), parser=parser)
        local = etree.QName(root).localname
        if local not in {'sitemapindex', 'urlset'}:
            raise FetchError('Not a sitemap XML document', 'index_format')
        return [('index' if local == 'sitemapindex' else 'page', u)
                for loc in root.xpath('//*[local-name()="loc"]/text()')
                if (u := scope.url(loc.strip(), url, index=local == 'sitemapindex'))]
    links = []
    for line in raw.splitlines():
        # The current docs index groups languages under level-two headings.
        if line.startswith('## ') and any(t in line.lower() for t in ('deutsch', 'german', 'español', 'français')):
            break
        for target in re.findall(r'\]\(([^\s)]+)', line):
            if u := scope.url(target, url):
                links.append(('page', u))
    return links


def coverage(state):
    counts = Counter(r['status'] for r in state['records'].values())
    sections = [s for p in state['pages'] for s in p['sections']]
    topics = []
    for i, (title, _, _) in enumerate(core.TOPICS):
        matches = [s for s in sections if s['topic'] == i]
        topics.append({'topic': title, 'collected_sections': len(matches), 'unique_sections': sum('duplicate_of' not in s for s in matches)})
    return {'run_id': state['run_id'], 'status': state['status'], 'page_statuses': dict(counts),
            'pending_pages': sum(t['kind'] == 'page' for t in state['queue']),
            'pending_indexes': sum(t['kind'] == 'index' for t in state['queue']),
            'sections': len(sections), 'exact_duplicates': sum('duplicate_of' in s for s in sections),
            'near_duplicates_retained': sum('near_duplicate_of' in s for s in sections),
            'topics': topics, 'limits': state['config'], 'discovery_truncated': state.get('discovery_truncated', False)}


class Engine:
    def __init__(self, directory, config, scope=None, fetcher=None, browser=None, state=None):
        self.directory, self.config = Path(directory), config
        self.scope = scope or Scope()
        self.fetcher = fetcher or Fetcher(self.scope, config)
        self.browser = browser
        self.state = state or {'schema_version': SCHEMA, 'tool_version': '2.0.0', 'run_id': self.directory.name,
            'collected_at': now(), 'updated_at': now(), 'config': vars(config).copy(), 'status': 'new', 'queue': [],
            'records': {}, 'index_records': {}, 'pages': [], 'issues': [], 'in_flight': None, 'robots': {}, 'sessions': []}
        scheduled = {('page', url_identity(u)) for u in self.state['records']}
        scheduled.update(('index', u) for u in self.state['index_records'])
        compact = []
        for task in self.state['queue']:
            key = (task['kind'], url_identity(task['url']))
            if key in scheduled or not self.scope.url(task['url'], index=task['kind']=='index'):
                continue
            if task['kind']=='index' and re.search(r'/(?:post|post_autors|category|tag|author)[-_]sitemap', task['url']):
                self.state.setdefault('excluded_indexes', []).append(task['url']);continue
            compact.append(task);scheduled.add(key)
        self.state['queue'] = compact
        self.known = {(t['kind'], url_identity(t['url'])) for t in self.state['queue']}
        self.known.update(('page', url_identity(u)) for u in self.state['records'])
        self.known.update(('index', u) for u in self.state['index_records'])
        if self.state.get('in_flight'):
            task = self.state['in_flight']
            if task['url'] not in (self.state['records'] if task['kind'] == 'page' else self.state['index_records']):
                self.state['queue'].insert(0, task)
                self.known.add((task['kind'], url_identity(task['url'])))
            self.state['in_flight'] = None

    def enqueue(self, url, depth=0, parent=None, kind='page', priority=20):
        url = self.scope.url(url, parent, index=kind == 'index')
        if not url or (kind == 'page' and priority != 0 and not self.scope.relevant(url)):
            return
        if kind == 'index' and re.search(r'/(?:post|post_autors|category|tag|author)[-_]sitemap', url):
            exclusions = self.state.setdefault('excluded_indexes', [])
            if url not in exclusions:
                exclusions.append(url)
            return
        if kind == 'page' and url.endswith('/llms.txt'):
            kind = 'index'
        key = (kind, url_identity(url))
        if key in self.known or depth > self.config.max_depth:
            return
        if len(self.known) >= self.config.max_frontier:
            self.state['discovery_truncated'] = True
            return
        self.known.add(key)
        self.state['queue'].append({'kind': kind, 'url': url, 'depth': depth, 'parent': parent, 'priority': priority})

    def initialise(self):
        for url in self.config.seeds:
            # Explicit seeds need not match relevance keywords.
            normal = self.scope.url(url)
            if not normal:
                raise ValueError('Seed outside allowed scope: ' + url)
            self.enqueue(normal, priority=0)
        self.checkpoint()
        if not self.config.no_discovery:
            if not self.scope.fixture_origin:
                self.enqueue('https://docs.aqua-cloud.io/documentation/llms.txt', kind='index', priority=-2)
            for url in self.config.seeds:
                self.fetcher.allowed(url)
            for urls in self.fetcher.sitemaps.values():
                for url in urls:
                    self.enqueue(url, kind='index', priority=-1)
        self.checkpoint()

    def checkpoint(self):
        self.state['updated_at'] = now()
        self.state['robots'].update(self.fetcher.robot_status)
        atomic_json(self.directory / 'checkpoint.json', self.state)

    def pick(self, allow_pages, allow_indexes):
        topic_counts = Counter(core.topic_for(u) for u in self.state['records'])
        candidates = [(i, t) for i, t in enumerate(self.state['queue'])
                      if (t['kind'] == 'page' and allow_pages) or (t['kind'] == 'index' and allow_indexes)]
        if not candidates:
            return None
        def index_rank(task):
            if task['kind'] != 'index':
                return 0
            if 'page-sitemap' in task['url'] or 'docs.aqua-cloud.io' in task['url']:
                return -5
            if re.search(r'/(post|category|tag|author|post_autors|success_stories|industries)[-_]sitemap',task['url']):
                return 25
            return 0
        i, _ = min(candidates, key=lambda item: (
            item[1]['priority'] + index_rank(item[1]) + item[1]['depth'] * 2 +
            (topic_counts[core.topic_for(item[1]['url'])] * 3 if item[1]['kind'] == 'page' and item[1]['priority'] > 0 else 0),
            len(item[1]['url']), item[0]))
        return self.state['queue'].pop(i)

    def run(self, budget, retry_failed=False):
        if retry_failed:
            for url, record in list(self.state['records'].items()):
                if record['status'] in {'failed', 'thin', 'blocked'}:
                    del self.state['records'][url]; self.known.discard(('page', url_identity(url)))
                    self.enqueue(url, record['depth'], record.get('parent'), priority=0)
        session = {'started_at': now(), 'page_budget': budget, 'page_attempts': 0, 'index_attempts': 0}
        self.state['sessions'].append(session); self.state['status'] = 'running'
        self.checkpoint()
        try:
            while task := self.pick(session['page_attempts'] < budget, session['index_attempts'] < self.config.max_indexes):
                self.state['in_flight'] = task; self.checkpoint()
                LOG.info('%s %s', task['kind'], task['url'])
                try:
                    if task['kind'] == 'index':
                        self.process_index(task); session['index_attempts'] += 1
                    else:
                        self.process_page(task); session['page_attempts'] += 1
                except (FetchError, core.FetchError, etree.ParserError, etree.XMLSyntaxError, ValueError) as e:
                    record = {**task, 'status': 'failed', 'reason': str(e), 'category': getattr(e, 'category', 'parse'), 'at': now()}
                    self.state['records' if task['kind'] == 'page' else 'index_records'][task['url']] = record
                    session['page_attempts' if task['kind'] == 'page' else 'index_attempts'] += 1
                    LOG.warning('%s: %s', task['url'], e)
                self.state['in_flight'] = None; self.checkpoint()
            self.state['status'] = 'budget_reached' if self.state['queue'] else 'complete'
        except KeyboardInterrupt:
            self.state['status'] = 'interrupted'
            LOG.warning('Interrupted. The in-flight URL will be retried on resume.')
        except Exception:
            self.state['status'] = 'error'
            raise
        finally:
            session['ended_at'] = now()
            if self.browser:
                self.browser.close()
            self.checkpoint()
            self.export()
        return 0 if self.state['pages'] else 2

    def process_index(self, task):
        result = self.fetcher.request(task['url'], index=True)
        links = index_links(result['raw'], result['url'], self.scope)
        for kind, url in links:
            # An index is a discovery source, not an extra product-navigation hop.
            self.enqueue(url, task['depth'], task['url'], kind, -1 if kind == 'index' else (8 if 'docs.aqua-cloud.io' in url else 12))
        self.state['index_records'][task['url']] = {**task, 'status': 'collected', 'discovered_links': len(links), 'at': now()}

    def process_page(self, task):
        url = task['url']
        pages, notes, states = [], [], []
        if self.config.mode != 'browser':
            result = self.fetcher.request(url)
            parsed = parse_page(result, self.scope)
            pages = [parsed]
        needs_browser = self.config.mode == 'browser' or (self.config.mode == 'auto' and pages[0]['quality']['status'] in {'thin', 'navigation'})
        if needs_browser:
            if self.browser is None:
                from browser_capture import BrowserCapture
                self.browser = BrowserCapture(self.scope, self.fetcher, self.config)
            try:
                snapshots, notes, states = self.browser.capture(url)
                candidates = [parse_page({'raw': s['html'], 'url': s['url'], 'content_type': 'text/html'}, self.scope) for s in snapshots]
                for page in candidates:
                    page['method'] = 'browser visible DOM'
                if candidates and any(p['quality']['status'] == 'usable' for p in candidates):
                    pages = candidates
                elif not pages:
                    pages = candidates
            except Exception as e:
                if not pages:
                    raise FetchError(str(e), 'browser') from e
                notes.append('Browser fallback failed: ' + str(e).splitlines()[0])
        if not pages:
            raise FetchError('No browser snapshots returned', 'browser')
        parsed = pages[0]
        status = 'usable' if any(p['quality']['status'] == 'usable' for p in pages) else parsed['quality']['status']
        if status != 'blocked' and task['depth'] < self.config.max_depth:
            for page in pages:
                for link in page['links']:
                    self.enqueue(link, task['depth'] + 1, url)
        record = {**task, 'status': 'collected' if status == 'usable' else status,
                  'at': now(), 'quality': parsed['quality'], 'notes': notes}
        if status == 'usable':
            parsed.update({'id': 'S' + digest(url)[:12], 'retrieved_at': now(), 'requested_url': url,
                           'notes': notes, 'interaction_states': states, 'topic': core.topic_for(url), 'depth': task['depth']})
            sections, seen = [], set()
            for n, page in enumerate(pages):
                page['id'] = parsed['id'] + (f'-V{n:02d}' if n else '')
                for section in split_sections(page):
                    key = (section['heading'], section['text_hash'])
                    if key not in seen:
                        section['state_index'] = n
                        section['source_url'] = page['url']
                        sections.append(section); seen.add(key)
            parsed['sections'] = sections
            parsed['characters'] = sum(len(b['text']) for s in sections for b in s['blocks'])
            parsed['links'] = sorted({u for p in pages for u in p['links']})
            self.state['pages'].append(parsed)
        self.state['records'][url] = record

    def export(self):
        deduplicate(self.state['pages'])
        self.checkpoint()
        summary = coverage(self.state)
        bundle = {'schema_version': SCHEMA, 'tool_version': '2.0.0', 'run_id': self.state['run_id'],
                  'collected_at': self.state['collected_at'], 'pages': self.state['pages'],
                  'attempted': len(self.state['records']), 'pending_count': summary['pending_pages'],
                  'issues': [{'url': u, 'reason': r.get('reason', r['status']), 'category': r.get('category', r['status'])}
                             for source in ('records', 'index_records') for u, r in self.state[source].items() if r['status'] != 'collected'],
                  'coverage': summary, 'pending_urls': [t['url'] for t in self.state['queue'] if t['kind'] == 'page'],
                  'indexes': self.state['index_records'], 'records': self.state['records']}
        atomic_json(self.directory / 'aqua_data.json', bundle)
        atomic_json(self.directory / 'coverage.json', summary)
        if bundle['pages']:
            from report import write_handbook
            stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
            reports = self.directory / 'reports'; reports.mkdir(exist_ok=True)
            report = reports / f'Aqua_Cloud_Handbook_{stamp}.docx'
            write_handbook(bundle, report, self.config.max_words_per_section)
            atomic_json(self.directory / 'latest_report.json', {'path': str(report.relative_to(self.directory)), 'created_at': now()})


def new_run(parent):
    directory = Path(parent).resolve() / ('run_' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '_' + uuid.uuid4().hex[:8])
    directory.mkdir(parents=True)
    return directory


def arguments(argv=None):
    p = argparse.ArgumentParser(description='Aqua Cloud Phase 1 collector and Word generator')
    p.add_argument('--output', default='output', help='Parent directory; each fresh run gets a unique dated folder')
    p.add_argument('--resume', help='Existing run folder containing checkpoint.json')
    p.add_argument('--retry-failed', action='store_true', help='On resume, requeue failed, blocked and thin pages')
    p.add_argument('--from-json', help='Rebuild a report from v1 or v2 aqua_data.json without network')
    p.add_argument('--seed', action='append')
    p.add_argument('--mode', choices=['auto', 'http', 'browser'], default='auto')
    p.add_argument('--max-pages', type=int, default=50, help='Additional page attempts in this invocation')
    p.add_argument('--max-depth', type=int, default=3)
    p.add_argument('--max-indexes', type=int, default=8, help='Additional index requests per invocation')
    p.add_argument('--max-frontier', type=int, default=5000)
    p.add_argument('--no-discovery', action='store_true', help='Disable automatic sitemap and documentation index bootstrap')
    p.add_argument('--delay', type=float, default=1)
    p.add_argument('--timeout', type=int, default=30)
    p.add_argument('--retries', type=int, default=2)
    p.add_argument('--max-words-per-section', type=int, default=0)
    p.add_argument('--headed', action='store_true')
    p.add_argument('--browser-executable', help='Optional path to an installed Chromium-compatible browser')
    p.add_argument('--proxy-env', action='store_true', help='Use HTTPS_PROXY or HTTP_PROXY for browser traffic; credentials are not saved')
    p.add_argument('--content-selector', default='main, [role="main"], article')
    p.add_argument('--ready-selector', help='Optional inspected element that must become visible')
    p.add_argument('--settle-ms', type=int, default=1200)
    p.add_argument('--max-scrolls', type=int, default=8)
    p.add_argument('--max-interactions', type=int, default=20)
    p.add_argument('--no-interact', action='store_true', help='Disable native details and ARIA tab collection')
    p.add_argument('--accordion-selector', help='Optional inspected button selector for content accordions')
    p.add_argument('--consent-selector', help='Optional inspected selector for your consent choice')
    p.add_argument('--next-selector', help='Optional inspected tour Next selector')
    a = p.parse_args(argv)
    if any(getattr(a, n) < 1 for n in ['max_pages', 'max_frontier', 'timeout', 'settle_ms']) or any(getattr(a,n)<0 for n in ['max_depth','max_indexes','delay','retries','max_scrolls','max_interactions','max_words_per_section']):
        p.error('Invalid negative or zero limit')
    if a.resume and (a.seed or a.from_json):
        p.error('--resume cannot be combined with --seed or --from-json')
    if a.retry_failed and not a.resume:
        p.error('--retry-failed requires --resume')
    return a


def main(argv=None):
    args = arguments(argv)
    if args.from_json:
        from report import write_handbook
        bundle = json.loads(Path(args.from_json).read_text(encoding='utf-8'))
        directory = new_run(args.output)
        write_handbook(bundle, directory / 'Aqua_Cloud_Handbook.docx', args.max_words_per_section)
        print(directory); return 0
    if args.resume:
        directory = Path(args.resume).resolve()
        if not (directory / 'checkpoint.json').exists():
            raise ValueError('Resume requires a Phase 1 checkpoint.json; v1 data can only be rebuilt with --from-json')
    else:
        directory = new_run(args.output)
    handler = logging.FileHandler(directory / 'scrape.log', encoding='utf-8')
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s', handlers=[logging.StreamHandler(), handler], force=True)
    print('Run directory:', directory, flush=True)
    with run_lock(directory):
        if args.resume:
            state = json.loads((directory / 'checkpoint.json').read_text(encoding='utf-8'))
            if state.get('schema_version') != SCHEMA:
                raise ValueError('Unsupported checkpoint schema')
            config = SimpleNamespace(**state['config'])
            if args.browser_executable:
                config.browser_executable = args.browser_executable
            LOG.info('Resuming saved configuration; --max-pages is an additional budget')
            engine = Engine(directory, config, state=state)
        else:
            config = SimpleNamespace(**{k: v for k, v in vars(args).items() if k not in {'output','resume','from_json','seed','max_pages','retry_failed'}})
            config.seeds = args.seed or core.SEEDS
            engine = Engine(directory, config)
            engine.initialise()
        result = engine.run(args.max_pages, args.retry_failed)
    LOG.info('Finished: %s collected pages; see coverage.json', len(engine.state['pages']))
    return result
