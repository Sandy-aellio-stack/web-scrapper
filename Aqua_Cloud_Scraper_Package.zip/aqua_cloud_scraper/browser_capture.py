"""Bounded read-only UI collection with explicit readiness and visible snapshots."""
import time
import os
from urllib.parse import urlsplit, unquote
from collection import FetchError, parse_page, digest

VISIBLE_HTML = r'''selector => {
  const source = document.querySelector(selector) || document.body;
  const clone = source.cloneNode(true);
  const originals = [source, ...source.querySelectorAll('*')];
  const copies = [clone, ...clone.querySelectorAll('*')];
  for (let i = originals.length - 1; i > 0; i--) {
    const e = originals[i], style = getComputedStyle(e);
    const hiddenByDetails = e.closest('details:not([open])') &&
      !e.closest('summary') && e.tagName !== 'DETAILS';
    if (style.display === 'none' || style.visibility === 'hidden' ||
        e.hidden || hiddenByDetails || ['SCRIPT','STYLE','NOSCRIPT'].includes(e.tagName)) copies[i].remove();
  }
  for (const e of [clone, ...clone.querySelectorAll('*')]) {
    for (const attr of [...e.attributes]) {
      if (attr.name.toLowerCase().startsWith('on')) e.removeAttribute(attr.name);
    }
  }
  return '<html><head><title>' + document.title.replaceAll('&','&amp;').replaceAll('<','&lt;') +
    '</title></head><body><main>' + clone.outerHTML + '</main></body></html>';
}'''


class BrowserCapture:
    def __init__(self, scope, fetcher, config):
        self.scope, self.fetcher, self.config = scope, fetcher, config
        self.manager = self.browser = self.context = None

    def start(self):
        if self.context:
            return
        try:
            from playwright.sync_api import sync_playwright
            self.manager = sync_playwright().start()
            options = {'headless': not self.config.headed}
            if self.config.browser_executable:
                options['executable_path'] = self.config.browser_executable
            if getattr(self.config,'proxy_env',False):
                value = os.environ.get('HTTPS_PROXY') or os.environ.get('https_proxy') or os.environ.get('HTTP_PROXY') or os.environ.get('http_proxy')
                if value:
                    proxy = urlsplit(value)
                    options['proxy'] = {'server':f'{proxy.scheme}://{proxy.hostname}:{proxy.port or 80}'}
                    if proxy.username:
                        options['proxy'].update(username=unquote(proxy.username),password=unquote(proxy.password or ''))
            self.browser = self.manager.chromium.launch(**options)
            self.context = self.browser.new_context(viewport={'width':1440, 'height':1000}, service_workers='block')
        except Exception as e:
            self.close()
            raise FetchError('Chromium launch failed. Run python -m playwright install chromium or set --browser-executable. ' + str(e).splitlines()[0], 'browser') from e

    def snapshot(self, page):
        return {'url': page.url, 'html': page.evaluate(VISIBLE_HTML, self.config.content_selector)}

    def signature(self, page):
        text = page.evaluate('s => (document.querySelector(s) || document.body).innerText', self.config.content_selector)
        return digest(text.strip())

    def settle(self, page, require_content=False, previous=None):
        deadline = time.monotonic() + self.config.timeout
        last, since = None, time.monotonic()
        changed = previous is None
        while time.monotonic() < deadline:
            current = self.signature(page)
            if previous is not None and current != previous:
                changed = True
            if current != last:
                last, since = current, time.monotonic()
            if time.monotonic() - since >= self.config.settle_ms / 1000:
                if not require_content and changed:
                    return True
                snap = self.snapshot(page)
                data = parse_page({**snap, 'raw': snap['html'], 'content_type':'text/html'}, self.scope)
                status = data['quality']['status']
                if status == 'blocked':
                    raise FetchError('Browser reached an access or consent wall', 'access')
                if status == 'usable' and changed:
                    return True
            page.wait_for_timeout(150)
        return False

    def capture(self, url):
        self.start()
        if not self.scope.url(url) or not self.fetcher.allowed(url):
            raise FetchError('Browser URL outside scope or disallowed by robots', 'robots')
        page = self.context.new_page()
        snapshots, notes, states, seen = [], [], [], set()

        def route_handler(route):
            request = route.request
            if request.is_navigation_request():
                target = self.scope.url(request.url)
                if not target or not self.fetcher.allowed(target):
                    route.abort(); return
            route.continue_()

        def record(action):
            snap = self.snapshot(page)
            fingerprint = digest(snap['html'])
            if fingerprint in seen:
                return False
            seen.add(fingerprint); snapshots.append(snap)
            states.append({'action':action, 'state_index':len(snapshots)-1, 'visible_text_hash':self.signature(page)})
            return True

        page.route('**/*', route_handler)
        page.on('dialog', lambda dialog: dialog.dismiss())
        try:
            self.fetcher.pace(url)
            response = page.goto(url, wait_until='domcontentloaded', timeout=self.config.timeout*1000)
            if response and response.status >= 400:
                raise FetchError(f'Browser HTTP {response.status}', 'http')
            if self.config.consent_selector:
                button = page.locator(self.config.consent_selector).first
                if button.count() and button.is_visible():
                    button.click(timeout=5000)
            if self.config.ready_selector:
                page.locator(self.config.ready_selector).first.wait_for(state='visible', timeout=self.config.timeout*1000)
            if not self.settle(page, require_content=True):
                notes.append('Readiness timeout: content may be incomplete')
            record('initial')
            stable_height, last_height = 0, -1
            for i in range(self.config.max_scrolls):
                height = page.evaluate('document.documentElement.scrollHeight')
                stable_height = stable_height + 1 if height == last_height else 0
                last_height = height
                page.evaluate('window.scrollTo(0, document.documentElement.scrollHeight)')
                page.wait_for_timeout(350); self.settle(page); record(f'scroll {i+1}')
                if stable_height >= 2:
                    break
            else:
                if self.config.max_scrolls:
                    notes.append('Scroll limit reached; further lazy content may exist')
            count = 0
            if not self.config.no_interact:
                summaries = page.locator('main details:not([open]) > summary, article details:not([open]) > summary, [role="main"] details:not([open]) > summary')
                while summaries.count() and count < self.config.max_interactions:
                    item = summaries.first
                    if not item.is_visible():
                        break
                    item.click(timeout=5000); count += 1
                    self.settle(page); record('native disclosure')
                tabs = page.locator('[role="tab"][aria-controls]')
                for n in range(tabs.count()):
                    if count >= self.config.max_interactions:
                        break
                    item = tabs.nth(n)
                    target = item.get_attribute('aria-controls')
                    valid = item.evaluate('(e) => {const p=document.getElementById(e.getAttribute("aria-controls")); return !e.closest("form,nav,header,footer") && !e.hasAttribute("href") && p && p.getAttribute("role")==="tabpanel";}')
                    if not valid or not item.is_visible() or not item.is_enabled() or item.get_attribute('aria-selected') == 'true':
                        continue
                    before = self.signature(page)
                    item.click(timeout=5000); count += 1
                    if not self.settle(page, previous=before):
                        notes.append('Tab did not produce a stable visible text change: ' + target)
                    record('ARIA tab ' + target)
            if self.config.accordion_selector:
                items = page.locator(self.config.accordion_selector)
                for n in range(items.count()):
                    if count >= self.config.max_interactions:
                        break
                    item = items.nth(n)
                    if item.is_visible() and item.is_enabled() and item.get_attribute('aria-expanded') != 'true':
                        item.click(timeout=5000); count += 1; self.settle(page); record('configured accordion')
            if self.config.next_selector:
                while count < self.config.max_interactions:
                    item = page.locator(self.config.next_selector).first
                    if not item.count() or not item.is_visible() or not item.is_enabled():
                        break
                    before = self.signature(page)
                    item.click(timeout=5000); count += 1
                    if not self.settle(page, previous=before) or not record('configured next'):
                        notes.append('Next control unchanged or repeated; stopped'); break
            if count >= self.config.max_interactions and count:
                notes.append('Interaction limit reached; additional states may exist')
            return snapshots, notes, states
        except Exception as error:
            if snapshots:
                notes.append('Interaction stopped after partial collection: '+str(error).splitlines()[0])
                return snapshots, notes, states
            raise
        finally:
            page.close()

    def close(self):
        if self.context:
            self.context.close()
        if self.browser:
            self.browser.close()
        if self.manager:
            self.manager.stop()
        self.context = self.browser = self.manager = None
