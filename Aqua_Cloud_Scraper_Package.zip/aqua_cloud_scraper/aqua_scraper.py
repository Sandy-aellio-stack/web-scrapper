#!/usr/bin/env python3
"""Aqua Cloud scraper entry point. Run --help for collection and resume options."""
import sys
from collection import main

if __name__ == '__main__':
    try:
        sys.exit(main())
    except (ValueError, RuntimeError, OSError) as error:
        print('Error:', error, file=sys.stderr)
        sys.exit(2)
