"""Word export retaining section source IDs and collection limitations."""
from pathlib import Path
from docx import Document
import content_core as core


def write_handbook(bundle, path, max_words=0):
    if bundle.get('schema_version', 1) < 2:
        core.write_report(bundle, path, max_words)
        return
    doc = Document(); core.configure_document(doc)
    doc.add_heading('Aqua Cloud Product Handbook', 0)
    doc.add_paragraph('Public product information organised by feature section', 'Subtitle')
    doc.add_paragraph('This handbook collects public source material into topic chapters. It provides a dated reference for understanding the product and finding the original documentation. Chapter introductions explain general QA concepts; the detailed sections preserve source wording. Vendor claims and availability statements are not independently verified.')
    doc.add_paragraph(f"Collected from {bundle['collected_at']}. Sources {len(bundle['pages'])}. Attempted URLs {bundle['attempted']}. Pending pages {bundle['pending_count']}.")
    summary = bundle.get('coverage', {})
    doc.add_heading('Collection coverage', 1)
    doc.add_paragraph(f"Run status {summary.get('status','unknown')}. Exact duplicate sections {summary.get('exact_duplicates',0)}. Similar sections retained {summary.get('near_duplicates_retained',0)}.")
    doc.add_paragraph('The page, index, depth and discovery limits bound this collection. Missing topics do not prove missing capabilities. Login screens, external iframe tours, video narration, image-only information and PDF contents are outside this phase. Browser captures can still miss content that loads after the configured readiness and interaction limits.')
    if max_words:
        doc.add_paragraph(f'Each source section is limited to {max_words} words in this reading copy. Full collected text is retained in aqua_data.json.')
    sections = [(page, section) for page in bundle['pages'] for section in page.get('sections', [])]
    for i, (name, _, intro) in enumerate(core.TOPICS):
        doc.add_heading(f'{i+1} {name}', 1); doc.add_paragraph(intro)
        group = [(p,s) for p,s in sections if s['topic']==i]
        if not group:
            doc.add_paragraph('No section was assigned to this topic in this run. Consult the coverage file and pending URLs before treating this chapter as complete.')
        for page, section in group:
            doc.add_heading(section['heading'], 2)
            p=doc.add_paragraph(f"[{section['id']}] ");core.hyperlink(p,page['title'],section.get('source_url',page['url']))
            if section.get('duplicate_of'):
                doc.add_paragraph('Identical collected passage appears under source section '+section['duplicate_of']+'. The full text and both source records remain in the JSON.')
                continue
            if section.get('near_duplicate_of'):
                doc.add_paragraph('Similar wording also appears in '+section['near_duplicate_of']+'. This passage is retained so distinct details are not lost.')
            left=max_words if max_words else float('inf')
            for block in section['blocks']:
                words=block['text'].split()
                if left<=0:
                    doc.add_paragraph('Remaining text omitted by the configured section word limit.');break
                doc.add_paragraph(' '.join(words[:int(left)]) if left!=float('inf') else block['text'])
                if len(words)>left:
                    doc.add_paragraph('Remaining text omitted by the configured section word limit.');break
                left-=len(words)
            if page.get('notes'):
                doc.add_paragraph('Collection notes: '+'; '.join(page['notes']))
    doc.add_heading('Collection issues', 1)
    if not bundle['issues']:
        doc.add_paragraph('No failed or incomplete attempted URLs were recorded. Pending URLs and crawl limits still apply.')
    for issue in bundle['issues']:
        doc.add_paragraph(issue['url']+' — '+issue['reason'])
    doc.add_heading('Source register', 1)
    for page in bundle['pages']:
        p=doc.add_paragraph(f"[{page['id']}] ");core.hyperlink(p,page['url'],page['url'])
        doc.add_paragraph(f"Retrieved {page['retrieved_at']}. Method {page['method']}.")
    temp=Path(path).with_suffix('.tmp.docx');doc.save(temp);temp.replace(path)
