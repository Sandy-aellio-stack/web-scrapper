"""Local public-page fixtures. No connection to the actual Aqua service."""
from collections import Counter
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import threading

PROSE = 'Requirements describe the expected behaviour of a system. A reviewer connects the requirement to its test cases and records coverage gaps before the next release. The recorded information helps the team identify missing checks and review changes.'


class FixtureServer:
    def __init__(self):
        self.hits = Counter(); self.fail_once = True
        owner = self
        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *a): pass
            def do_GET(self):
                path = self.path.split('?')[0].rstrip('/') or '/'
                owner.hits[path] += 1
                status, kind, extra = 200, 'text/html', {}
                if path == '/robots.txt':
                    kind='text/plain'; body=f'User-agent: *\nDisallow: /private/\nSitemap: {owner.origin}/sitemap.xml\n'
                elif path == '/sitemap.xml':
                    kind='application/xml'; body=f'<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><sitemap><loc>{owner.origin}/pages.xml</loc></sitemap><sitemap><loc>{owner.origin}/sitemap.xml</loc></sitemap></sitemapindex>'
                elif path == '/pages.xml':
                    kind='application/xml'; body=f'<urlset><url><loc>{owner.origin}/requirements/</loc></url><url><loc>{owner.origin}/pricing/</loc></url><url><loc>https://evil.invalid/</loc></url></urlset>'
                elif path == '/':
                    body=f'<html><title>Product</title><main><h1>Product overview</h1><p>{PROSE}</p><a href="/requirements/">Requirements</a><a href="/pricing/">Pricing</a></main></html>'
                elif path in ('/requirements','/pricing','/duplicate'):
                    title='Requirements' if path != '/pricing' else 'Pricing'
                    body=f'<html><title>{title}</title><main><h1>{title}</h1><p>{PROSE}</p><h2>Bug tracking</h2><p>Defect records describe actual behaviour and the expected result. Teams use these details to investigate a failure and plan a correction.</p></main></html>'
                elif path == '/redirect':
                    status=302; extra['Location']=owner.origin+'/requirements/';body=''
                elif path == '/external':
                    status=302;extra['Location']='https://evil.invalid/';body=''
                elif path == '/retry' and owner.fail_once:
                    owner.fail_once=False;status=503;body='Temporary failure'
                elif path == '/retry':
                    body=f'<main><h1>Requirements</h1><p>{PROSE}</p></main>'
                elif path == '/limited':
                    status=429;extra['Retry-After']='120';body='Try later'
                elif path == '/blocked':
                    body='<html><title>Access denied</title><main><h1>Access denied</h1><p>'+PROSE*10+'</p></main></html>'
                elif path == '/empty':
                    body='<html><title>Loading</title><main><h1>Loading</h1></main></html>'
                elif path == '/markdown.md':
                    kind='text/markdown';body='# Test cases\n\n'+PROSE+'\n\n## Pricing\n\nContact the vendor to establish the applicable billing period and included subscription features.'
                elif path == '/dynamic':
                    body='''<html><title>Dynamic guide</title><main id="main"><h1>Loading</h1></main>
                    <script>setTimeout(()=>{document.getElementById('main').innerHTML=`
                    <h1>Requirements guide</h1><p>Requirements capture expected behaviour and connect it to the relevant test cases. This information is loaded after JavaScript executes and must be collected from the rendered document.</p>
                    <details><summary>Execution details</summary><p>Hidden disclosure evidence explains how a reviewer records test outcomes and follows up on a failed execution.</p></details>
                    <button role="tab" aria-controls="panel1" aria-selected="true" onclick="tab(1)">First</button>
                    <button role="tab" aria-controls="panel2" aria-selected="false" onclick="tab(2)">Second</button>
                    <section role="tabpanel" id="panel1"><h2>Test cases</h2><p>First tab content describes reusable test cases and expected results for each action in the scenario.</p></section>
                    <section role="tabpanel" id="panel2" hidden><h2>Defect investigation</h2><p>Second tab evidence describes defect reproduction steps and observed outcomes that support investigation.</p></section>
                    <div id="step"><h2>Tour stage one</h2><p>Stage one explains how to begin reviewing a requirement and identify the related validation work.</p></div>
                    <button id="next" onclick="document.getElementById('step').innerHTML='<h2>Tour stage two</h2><p>Stage two evidence describes reviewing the recorded results and documenting any unresolved differences.</p>';this.disabled=true">Next</button>
                    <p style="display:none">Invisible trap must not enter a visible browser snapshot.</p>`;},350);
                    function tab(n){document.querySelectorAll('[role=tabpanel]').forEach((p,i)=>p.hidden=i!==n-1);document.querySelectorAll('[role=tab]').forEach((b,i)=>b.setAttribute('aria-selected',String(i===n-1)));}
                    </script></html>'''
                elif path == '/controls':
                    body='''<html><title>Product controls</title>
                    <button id="consent" onclick="document.querySelector('main').hidden=false;this.remove()">Allow content</button>
                    <main hidden><h1>Test execution</h1><p>Execution records describe which tests were run and the observed results. Reviewers use this evidence to investigate failures and decide whether further checks are required.</p>
                    <button id="accordion" aria-expanded="false" onclick="this.setAttribute('aria-expanded','true');document.getElementById('answer').hidden=false">Show details</button>
                    <section id="answer" hidden><h2>Execution evidence</h2><p>Configured accordion evidence includes the observed result, reviewer notes and the relationship with the original test case.</p></section></main></html>'''
                else:
                    status=404;body='Not found'
                data=body.encode();self.send_response(status)
                self.send_header('Content-Type',kind+'; charset=utf-8')
                for key,value in extra.items():self.send_header(key,value)
                self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
        self.server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
        self.origin=f'http://127.0.0.1:{self.server.server_port}'
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True)

    def __enter__(self):self.thread.start();return self
    def __exit__(self,*a):self.server.shutdown();self.server.server_close();self.thread.join()
