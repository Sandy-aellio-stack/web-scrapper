import copy
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from types import SimpleNamespace
from docx import Document

from collection import *
from fixture_server import FixtureServer, PROSE


def config(origin='https://aqua-cloud.io', **kwargs):
    args=vars(arguments([]))
    args.update(seeds=[origin+'/'],delay=0,timeout=3,retries=0,no_discovery=True,mode='http',settle_ms=200,max_scrolls=0)
    args.update(kwargs)
    return SimpleNamespace(**args)


class ContentTests(unittest.TestCase):
    def parse(self, raw):
        return parse_page({'raw':raw,'url':'https://aqua-cloud.io/product-tour/','content_type':'text/html'},Scope())

    def test_access_wall_not_accepted_as_long_article(self):
        p=self.parse('<title>Access denied</title><main><h1>Access denied</h1><p>'+PROSE*10+'</p></main>')
        self.assertEqual(p['quality']['status'],'blocked')

    def test_short_meaningful_article_is_usable(self):
        p=self.parse('<main><h1>Test cases</h1><p>A test case records the expected result for the actions performed by a tester.</p></main>')
        self.assertEqual(p['quality']['status'],'usable')

    def test_empty_loading_screen_is_thin(self):
        self.assertEqual(self.parse('<main><h1>Loading</h1></main>')['quality']['status'],'thin')

    def test_login_documentation_is_not_a_login_wall(self):
        p=self.parse('<title>Login documentation</title><main><h1>Login</h1><p>'+PROSE+' This guide describes the login workflow and supported authentication options.</p><p>'+PROSE+' Follow the documented account recovery instructions when required.</p><p>'+PROSE+' Contact the administrator for help with access settings.</p></main>')
        self.assertEqual(p['quality']['status'],'usable')

    def test_page_sections_get_different_topics(self):
        p=self.parse('<main><h1>Requirements</h1><p>'+PROSE+'</p><h2>Bug tracking</h2><p>Defect records explain a failure and its reproduction steps.</p></main>');p['id']='S1'
        sections=split_sections(p)
        self.assertEqual([s['topic'] for s in sections],[1,4])
        self.assertEqual(sections[1]['heading_path'],['Requirements','Bug tracking'])

    def test_availability_label_stays_with_following_feature(self):
        p=self.parse('<main><h1>Requirements</h1><p>'+PROSE+'</p><span>COMING SOON</span><h2>AI Copilot</h2><p>The AI assistant will explain the recorded requirements to the reviewer.</p></main>');p['id']='S1'
        ss=split_sections(p)
        self.assertEqual(ss[1]['blocks'][0]['text'],'COMING SOON')
        self.assertNotIn('COMING SOON',str(ss[0]))

    def test_exact_duplicate_preserves_both_sources(self):
        p=self.parse('<main><h1>Requirements</h1><p>'+PROSE+'</p></main>');p['id']='S1';p['sections']=split_sections(p)
        p2=copy.deepcopy(p);p2['id']='S2';p2['sections'][0]['id']='S2-C001'
        deduplicate([p,p2]);self.assertEqual(p2['sections'][0]['duplicate_of'],'S1-C001')
        self.assertIn(PROSE,str(p2['sections'][0]['blocks']))

    def test_near_duplicate_with_changed_number_retained(self):
        text=PROSE+' The configured retention period is 30 days.'
        def page(id,body):
            p=self.parse('<main><h1>Requirements</h1><p>'+body+'</p></main>');p['id']=id;p['sections']=split_sections(p);return p
        p1,p2=page('S1',text),page('S2',text.replace('30','90'))
        deduplicate([p1,p2]);s=p2['sections'][0]
        self.assertNotIn('duplicate_of',s);self.assertIn('near_duplicate_of',s);self.assertIn('90',str(s['blocks']))

    def test_scope_and_tracking_normalisation(self):
        s=Scope()
        self.assertEqual(s.url('https://www.aqua-cloud.io/pricing?utm=x#foo'),'https://aqua-cloud.io/pricing/')
        for u in ['https://aqua-cloud.io.evil.invalid/','https://app.aqua-cloud.io/','http://aqua-cloud.io/','https://aqua-cloud.io:8888/','https://aqua-cloud.io/%2e%2e/private','file:///etc/passwd']:
            self.assertIsNone(s.url(u))

    def test_sitemap_nested_and_external_scope(self):
        text='<sitemapindex><sitemap><loc>https://aqua-cloud.io/pages.xml</loc></sitemap><sitemap><loc>https://evil.invalid/x.xml</loc></sitemap></sitemapindex>'
        self.assertEqual(index_links(text,'https://aqua-cloud.io/sitemap.xml',Scope()),[('index','https://aqua-cloud.io/pages.xml')])

    def test_llms_language_boundary(self):
        raw='## English\n- [Guide](https://docs.aqua-cloud.io/documentation/guide.md)\n## Deutsch\n- [Anderes](https://docs.aqua-cloud.io/documentation/anderes.md)'
        self.assertEqual(len(index_links(raw,'https://docs.aqua-cloud.io/documentation/llms.txt',Scope())),1)

    def test_editorial_sitemap_is_excluded(self):
        with tempfile.TemporaryDirectory() as directory:
            e=Engine(directory,config())
            e.enqueue('https://aqua-cloud.io/post-sitemap.xml',kind='index')
            self.assertFalse(e.state['queue'])
            self.assertEqual(len(e.state['excluded_indexes']),1)

    def test_markdown_html_urls_share_frontier_identity(self):
        with tempfile.TemporaryDirectory() as directory:
            e=Engine(directory,config())
            e.enqueue('https://docs.aqua-cloud.io/documentation/web-client/general.md')
            e.enqueue('https://docs.aqua-cloud.io/documentation/web-client/general')
            self.assertEqual(len(e.state['queue']),1)

    def test_xml_entities_not_expanded(self):
        xml='<!DOCTYPE urlset [<!ENTITY secret SYSTEM "file:///etc/passwd">]><urlset><url><loc>&secret;</loc></url></urlset>'
        self.assertEqual(index_links(xml,'https://aqua-cloud.io/sitemap.xml',Scope()),[])


class NetworkAndResumeTests(unittest.TestCase):
    def setUp(self):
        self.server=FixtureServer().__enter__();self.tmp=tempfile.TemporaryDirectory();self.path=Path(self.tmp.name)
        self.scope=Scope(self.server.origin);self.cfg=config(self.server.origin)
    def tearDown(self):self.server.__exit__();self.tmp.cleanup()
    def engine(self,**kwargs):return Engine(self.path,self.cfg,self.scope,**kwargs)

    def test_robots_denied_path_not_requested(self):
        f=Fetcher(self.scope,self.cfg)
        with self.assertRaises(FetchError):f.request(self.server.origin+'/private/data/')
        self.assertEqual(self.server.hits['/private/data'],0)

    def test_external_redirect_is_not_followed(self):
        with self.assertRaisesRegex(FetchError,'outside'):Fetcher(self.scope,self.cfg).request(self.server.origin+'/external/')

    def test_internal_redirect(self):
        result=Fetcher(self.scope,self.cfg).request(self.server.origin+'/redirect/')
        self.assertTrue(result['url'].endswith('/requirements/'))

    def test_503_retry(self):
        self.cfg.retries=1
        with patch('collection.time.sleep'):
            result=Fetcher(self.scope,self.cfg).request(self.server.origin+'/retry/')
        self.assertEqual(result['status'],200);self.assertEqual(self.server.hits['/retry'],2)

    def test_long_retry_after_is_not_ignored(self):
        self.cfg.retries=1
        with self.assertRaisesRegex(FetchError,'more than 60'):Fetcher(self.scope,self.cfg).request(self.server.origin+'/limited/')
        self.assertEqual(self.server.hits['/limited'],1)

    def test_sitemap_discovery_is_bounded_and_cycle_safe(self):
        self.cfg.no_discovery=False
        e=self.engine();e.initialise();e.run(2)
        self.assertEqual(self.server.hits['/sitemap.xml'],1)
        self.assertEqual(self.server.hits['/pages.xml'],1)
        self.assertGreaterEqual(len(e.state['records']),2)
        self.assertFalse(any('evil.invalid' in t['url'] for t in e.state['queue']))

    def test_budget_resume_does_not_refetch_completed_pages(self):
        e=self.engine();e.initialise();e.run(1)
        first=set(e.state['records']);state=json.loads((self.path/'checkpoint.json').read_text())
        resumed=self.engine(state=state);resumed.run(1)
        self.assertEqual(len(resumed.state['records']),2)
        for u in first:self.assertEqual(self.server.hits[urlsplit(u).path.rstrip('/') or '/'],1)
        self.assertEqual(len(list((self.path/'reports').glob('*.docx'))),2)

    def test_interruption_recovers_inflight_task(self):
        e=self.engine();e.initialise()
        with patch.object(e,'process_page',side_effect=KeyboardInterrupt):e.run(1)
        state=json.loads((self.path/'checkpoint.json').read_text())
        self.assertEqual(state['status'],'interrupted');self.assertIsNotNone(state['in_flight'])
        resumed=self.engine(state=state);resumed.run(1)
        self.assertEqual(len(resumed.state['pages']),1);self.assertIsNone(resumed.state['in_flight'])

    def test_failed_page_can_be_retried_without_success_duplicates(self):
        self.cfg.seeds=[self.server.origin+'/retry/']
        e=self.engine();e.initialise();e.run(1)
        self.assertEqual(e.state['records'][self.cfg.seeds[0]]['status'],'failed')
        state=json.loads((self.path/'checkpoint.json').read_text())
        resumed=self.engine(state=state);resumed.run(1,retry_failed=True)
        self.assertEqual(len(resumed.state['pages']),1)

    def test_no_content_does_not_create_new_report(self):
        self.cfg.seeds=[self.server.origin+'/empty/']
        e=self.engine();e.initialise();self.assertEqual(e.run(1),2)
        self.assertFalse((self.path/'reports').exists())
        self.assertEqual(e.state['records'][self.cfg.seeds[0]]['status'],'thin')

    def test_blocked_long_page_is_not_recorded_as_product(self):
        self.cfg.seeds=[self.server.origin+'/blocked/']
        e=self.engine();e.initialise();e.run(1)
        self.assertFalse(e.state['pages']);self.assertEqual(e.state['records'][self.cfg.seeds[0]]['status'],'blocked')

    def test_discovery_frontier_limit_is_visible(self):
        self.cfg.max_frontier=1
        e=self.engine();e.initialise();e.run(1)
        self.assertTrue(e.state['discovery_truncated'])
        self.assertTrue(json.loads((self.path/'coverage.json').read_text())['discovery_truncated'])

    def test_new_run_folders_do_not_collide(self):
        self.assertNotEqual(new_run(self.path),new_run(self.path))

    def test_unexpected_failure_keeps_inflight_for_recovery(self):
        e=self.engine();e.initialise()
        with patch.object(e,'process_page',side_effect=RuntimeError('simulated crash')):
            with self.assertRaises(RuntimeError):e.run(1)
        saved=json.loads((self.path/'checkpoint.json').read_text())
        self.assertEqual(saved['status'],'error');self.assertIsNotNone(saved['in_flight'])
        resumed=self.engine(state=saved);resumed.run(1)
        self.assertEqual(len(resumed.state['pages']),1)

    def test_offline_v2_rebuild(self):
        e=self.engine();e.initialise();e.run(1)
        with patch.object(Fetcher,'request',side_effect=AssertionError('offline rebuild made request')):
            self.assertEqual(main(['--from-json',str(self.path/'aqua_data.json'),'--output',str(self.path/'rebuilt')]),0)
        self.assertEqual(len(list((self.path/'rebuilt').glob('run_*/*.docx'))),1)

    def test_word_contains_multiple_topics_and_source_ids(self):
        self.cfg.seeds=[self.server.origin+'/requirements/']
        e=self.engine();e.initialise();e.run(1)
        doc=Document(next((self.path/'reports').glob('*.docx')))
        text='\n'.join(p.text for p in doc.paragraphs)
        self.assertIn('Bug tracking',text);self.assertIn('Requirements',text)
        self.assertIn(e.state['pages'][0]['sections'][0]['id'],text)

    def test_last_block_truncation_is_labelled(self):
        from report import write_handbook
        e=self.engine();e.initialise();e.run(1)
        bundle=json.loads((self.path/'aqua_data.json').read_text())
        target=self.path/'short.docx';write_handbook(bundle,target,5)
        self.assertIn('Remaining text omitted', '\n'.join(p.text for p in Document(target).paragraphs))

    def test_run_lock_rejects_competing_writer(self):
        with run_lock(self.path):
            with self.assertRaises(RuntimeError):
                with run_lock(self.path):pass


@unittest.skipUnless(os.environ.get('AQUA_BROWSER_TESTS')=='1','Set AQUA_BROWSER_TESTS=1 for real Chromium tests')
class BrowserTests(unittest.TestCase):
    def test_explicit_consent_and_accordion(self):
        from browser_capture import BrowserCapture
        with FixtureServer() as server:
            cfg=config(server.origin,mode='browser',consent_selector='#consent',accordion_selector='#accordion',ready_selector='main h1',timeout=4,browser_executable=os.environ.get('AQUA_BROWSER_EXECUTABLE'))
            scope=Scope(server.origin);browser=BrowserCapture(scope,Fetcher(scope,cfg),cfg)
            try:
                snaps,notes,states=browser.capture(server.origin+'/controls/')
                self.assertIn('Configured accordion evidence',str(snaps))
                self.assertTrue(any(s['action']=='configured accordion' for s in states))
            finally:browser.close()

    def test_interaction_limit_stops_before_next(self):
        from browser_capture import BrowserCapture
        with FixtureServer() as server:
            cfg=config(server.origin,mode='browser',next_selector='#next',max_interactions=1,timeout=4,browser_executable=os.environ.get('AQUA_BROWSER_EXECUTABLE'))
            scope=Scope(server.origin);browser=BrowserCapture(scope,Fetcher(scope,cfg),cfg)
            try:
                snaps,notes,states=browser.capture(server.origin+'/dynamic/')
                self.assertNotIn('Stage two evidence',str(snaps))
                self.assertTrue(any('Interaction limit' in n for n in notes))
            finally:browser.close()

    def test_dynamic_content_tabs_details_and_next(self):
        from browser_capture import BrowserCapture
        with FixtureServer() as server:
            cfg=config(server.origin,mode='browser',next_selector='#next',timeout=4,browser_executable=os.environ.get('AQUA_BROWSER_EXECUTABLE'))
            scope=Scope(server.origin);browser=BrowserCapture(scope,Fetcher(scope,cfg),cfg)
            try:
                snaps,notes,states=browser.capture(server.origin+'/dynamic/')
                text='\n'.join(str(parse_page({'raw':s['html'],'url':s['url'],'content_type':'text/html'},scope)['blocks']) for s in snaps)
                self.assertIn('Hidden disclosure evidence',text)
                self.assertIn('Second tab evidence',text)
                self.assertIn('Stage two evidence',text)
                self.assertNotIn('Invisible trap',text)
                self.assertGreaterEqual(len(states),4)
                self.assertTrue(any(s['action']=='configured next' for s in states))
                self.assertFalse(any('timeout' in n.lower() for n in notes))
            finally:browser.close()

    def test_auto_fallback_collects_rendered_sections(self):
        with FixtureServer() as server,tempfile.TemporaryDirectory() as directory:
            cfg=config(server.origin,mode='auto',seeds=[server.origin+'/dynamic/'],timeout=4,browser_executable=os.environ.get('AQUA_BROWSER_EXECUTABLE'))
            e=Engine(directory,cfg,Scope(server.origin));e.initialise();e.run(1)
            self.assertEqual(len(e.state['pages']),1)
            self.assertEqual(e.state['pages'][0]['method'],'browser visible DOM')
            text=str(e.state['pages'][0]['sections'])
            self.assertIn('Second tab evidence',text);self.assertIn('Hidden disclosure evidence',text)


if __name__=='__main__':unittest.main()
