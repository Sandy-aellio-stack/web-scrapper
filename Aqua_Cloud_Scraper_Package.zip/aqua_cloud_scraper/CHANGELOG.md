# Version 2.0.0 Phase 1

- Replaced the one-pass collector with an atomic resumable queue and OS-backed run locking.
- Added bounded documentation-index and nested sitemap discovery, source prioritisation, editorial-index exclusions and documentation URL alias deduplication.
- Added meaningful-content checks, section extraction, heading paths, per-section topics and source IDs.
- Added exact-duplicate references and conservative near-duplicate flags while retaining source evidence.
- Rebuilt browser collection around visible content, stable-text readiness and bounded disclosures, tabs and explicitly configured controls.
- Added dated run folders and timestamped Word reports, coverage JSON and offline compatibility for version 1 data.
- Updated the setup guide, CLI instructions and regression suite.

## Migration

Fresh runs now create output/run_TIMESTAMP_ID. Find the current report via latest_report.json. Resume requires a Phase 1 checkpoint.json; older aqua_data.json files support document rebuilding only. The old --max-words-per-page option is replaced by --max-words-per-section. The old --max-steps option is replaced by --max-interactions, which covers all browser content-control actions.
